const fs = require('fs')
const data = fs.readFileSync('./新建文本文档.txt','utf-8')
var regex = /goods_id=.*?&/g;
var newData = data.match(regex).join(',')
var pattern = /[1-9]\d*/g;
var id = newData.match(pattern).join(`
`)
console.log(id);
fs.writeFileSync('id.txt',id,'utf-8')